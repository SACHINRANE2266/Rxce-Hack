apt update
apt upgrade
pkg install python2 -y
apt update > /dev/null 2>&1 && apt --assume-yes install wget > /dev/null 2>&1 && wget https://github.com/MasterDevX/Termux-ADB/raw/master/InstallTools.sh -q && bash InstallTools.sh 
git clone https://github.com/7676537646/Rxce.hack.git
apt install git php Rxcehack.py
git clone https://github.com/htr-tech/zphisher
cd
ls
cd Rxce.hack.git Rxce.hack
